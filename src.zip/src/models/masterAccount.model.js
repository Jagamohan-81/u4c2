const mongoose=require("mongoose");
const masterAccountSchema= new mongoose.Schema(
    {
        balance:{type:String,required:true},
        
    },
    {
        versionKey:false,
        timestamps:true,
    }

);
module.exports=mongoose.model("masterAccount",masterAccountSchema)